% Created in September 2020 by imperix ltd
% Julien Orsinger <julien.orsinger@imperix.ch>

fsw = 20e3;     % switching frequency [Hz]
Ltot = 30e-6;   % power transfer inductance [H]
V1 = 50;        % input voltage [V]
Rout = 10;      % load resistance [Ohm]
n = 1;          % transformer turn ratio [-]